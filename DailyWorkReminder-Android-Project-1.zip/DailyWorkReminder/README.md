# Daily Work Reminder (Android)

An offline-first Android starter app for daily and monthly work tracking.

## Features
- Add tasks with a date and reminder time
- One-time, daily, or monthly reminders
- Mark tasks completed or pending
- Monthly task count and completion summary
- Delete tasks
- Tasks are stored locally on the device; no account or internet connection is required

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this `DailyWorkReminder` folder in Android Studio.
3. Let Gradle sync and install the Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio creates the APK under `app/build/outputs/apk/debug/`.

## Notes
- On Android 13+, allow notification permission when prompted.
- On Android 12+, exact alarm access may be restricted by the device. If the app cannot schedule exact alarms, it falls back to an inexact alarm.
- Battery optimization and manufacturer background limits can affect delivery.
- This is a starter project source, not a precompiled APK.
