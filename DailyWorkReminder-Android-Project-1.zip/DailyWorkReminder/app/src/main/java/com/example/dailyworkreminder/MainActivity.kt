package com.example.dailyworkreminder

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.app.AlertDialog
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class WorkTask(val id: Long, val title: String, val date: String, val time: String, val repeat: String, var done: Boolean)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tasks", MODE_PRIVATE) }
    private val tasks = mutableListOf<WorkTask>()
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        load()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 16) }
        val heading = TextView(this).apply { text = "Daily Work Reminder"; textSize = 25f; setTextColor(0xff17324d.toInt()) }
        summary = TextView(this).apply { textSize = 15f; setPadding(0, 12, 0, 12) }
        val add = Button(this).apply { text = "+ Add work / reminder"; setOnClickListener { addTask() } }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(heading); root.addView(summary); root.addView(add)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        render()
    }

    private fun addTask() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 8, 12, 8) }
        val title = EditText(this).apply { hint = "Work / task name" }
        val date = EditText(this).apply { hint = "Date (YYYY-MM-DD)"; setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val time = EditText(this).apply { hint = "Reminder time (HH:MM, 24-hour)"; setText("09:00") }
        val repeat = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Once", "Daily", "Monthly")) }
        box.addView(title); box.addView(date); box.addView(time); box.addView(repeat)
        AlertDialog.Builder(this).setTitle("Add work").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val t = title.text.toString().trim()
                val d = date.text.toString().trim()
                val tm = time.text.toString().trim()
                if (t.isEmpty() || !validDate(d) || !validTime(tm)) {
                    Toast.makeText(this, "Enter a task, valid date and time.", Toast.LENGTH_LONG).show(); return@setPositiveButton
                }
                val item = WorkTask(System.currentTimeMillis(), t, d, tm, repeat.selectedItem.toString(), false)
                tasks.add(item); save(); schedule(item); render()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun validDate(s: String) = try { SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(s) != null } catch (_: Exception) { false }
    private fun validTime(s: String) = Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(s)

    private fun render() {
        list.removeAllViews()
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val month = today.substring(0, 7)
        val completed = tasks.count { it.done }
        summary.text = "This month: ${tasks.count { it.date.startsWith(month) }} tasks  •  Completed: $completed  •  Pending: ${tasks.size - completed}"
        tasks.sortedWith(compareBy<WorkTask> { it.date }.thenBy { it.time }).forEach { task ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 8, 0, 8) }
            val check = CheckBox(this).apply {
                text = "${task.title}\n${task.date} at ${task.time}  •  ${task.repeat}"
                textSize = 15f; isChecked = task.done
                setOnCheckedChangeListener { _, checked -> task.done = checked; save(); render() }
            }
            val delete = ImageButton(this).apply {
                setImageResource(android.R.drawable.ic_menu_delete); contentDescription = "Delete task"
                setOnClickListener { AlertDialog.Builder(this@MainActivity).setMessage("Delete this task?")
                    .setPositiveButton("Delete") { _, _ -> cancel(task); tasks.remove(task); save(); render() }
                    .setNegativeButton("Cancel", null).show() }
            }
            row.addView(check, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(delete)
            list.addView(row)
            val line = android.view.View(this).apply { setBackgroundColor(0xffdddddd.toInt()) }
            list.addView(line, LinearLayout.LayoutParams(-1, 1))
        }
        if (tasks.isEmpty()) list.addView(TextView(this).apply { text = "No tasks yet. Tap Add work to get started."; setPadding(0, 24, 0, 0); textSize = 16f })
    }

    private fun save() {
        val a = JSONArray()
        tasks.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("date", it.date).put("time", it.time).put("repeat", it.repeat).put("done", it.done)) }
        prefs.edit().putString("items", a.toString()).apply()
    }
    private fun load() {
        tasks.clear()
        try {
            val a = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); tasks.add(WorkTask(o.getLong("id"), o.getString("title"), o.getString("date"), o.getString("time"), o.getString("repeat"), o.optBoolean("done"))) }
        } catch (_: Exception) {}
    }
    private fun schedule(t: WorkTask) {
        val cal = Calendar.getInstance()
        val parts = t.date.split("-").map { it.toInt() }
        val hm = t.time.split(":").map { it.toInt() }
        cal.set(parts[0], parts[1]-1, parts[2], hm[0], hm[1], 0); cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) return
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", t.title).putExtra("id", t.id).putExtra("repeat", t.repeat)
        val pi = PendingIntent.getBroadcast(this, t.id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
    private fun cancel(t: WorkTask) {
        val pi = PendingIntent.getBroadcast(this, t.id.toInt(), Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("work_reminders", "Work reminders", NotificationManager.IMPORTANCE_DEFAULT)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Work reminder"
        val id = intent.getLongExtra("id", 1L)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, "work_reminders") else Notification.Builder(context)
        n.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Work reminder").setContentText(title).setAutoCancel(true)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id.toInt(), n.build())
        // Repeating reminders are scheduled again from the saved task list.
        val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optLong("id") == id && o.optString("repeat") != "Once" && !o.optBoolean("done")) {
                    val cal = Calendar.getInstance()
                    if (o.optString("repeat") == "Daily") cal.add(Calendar.DAY_OF_YEAR, 1) else cal.add(Calendar.MONTH, 1)
                    val hm = o.getString("time").split(":").map { it.toInt() }
                    cal.set(Calendar.HOUR_OF_DAY, hm[0]); cal.set(Calendar.MINUTE, hm[1]); cal.set(Calendar.SECOND, 0)
                    val next = Intent(context, ReminderReceiver::class.java).putExtra("title", o.getString("title")).putExtra("id", id).putExtra("repeat", o.getString("repeat"))
                    val pi = PendingIntent.getBroadcast(context, id.toInt(), next, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            }
        } catch (_: Exception) {}
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optBoolean("done")) continue
                val d = o.getString("date").split("-").map { it.toInt() }
                val hm = o.getString("time").split(":").map { it.toInt() }
                val cal = Calendar.getInstance().apply { set(d[0], d[1]-1, d[2], hm[0], hm[1], 0); set(Calendar.MILLISECOND, 0) }
                if (cal.timeInMillis <= System.currentTimeMillis()) continue
                val id = o.getLong("id")
                val i2 = Intent(context, ReminderReceiver::class.java).putExtra("title", o.getString("title")).putExtra("id", id).putExtra("repeat", o.getString("repeat"))
                val pi = PendingIntent.getBroadcast(context, id.toInt(), i2, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
        } catch (_: Exception) {}
    }
}
